## In the Server
npm install
npm install dotenv
npm install morgan
npm install express
npm install twitter

make sure to change the .env file to your specific keys for your twitter API 

## In client
npm install
npm install natural

## To run
client: npm run build
server: node index
http://localhost:3000