const natural = require('natural')

natural.BayesClassifier.load('classifier.json', null, function (err, classifier) {
    if (err) {
        console.log(err)
        return
    }
    // returns negative
    console.log(classifier.classify('i hate this'))
})