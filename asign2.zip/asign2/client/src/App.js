import React from 'react';
import './App.css';
import TwitterRoute from './twitterclient.js'

function App() {
  return (
    <div>
      <TwitterRoute/>
    </div>
  );
}

export default App;
